from django.shortcuts import render,redirect
from django.http import HttpResponse
from accounts.models import *

from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.http import JsonResponse

from .forms import RegisterForm
from .salesforce_service import SalesforceService

import requests
from django.shortcuts import render

def register_view(request):

    if request.method == 'POST':

        form = RegisterForm(request.POST)

        if form.is_valid():
            form.save()
            return redirect('login')

    else:
        form = RegisterForm()

    return render(request, 'register.html', {'form': form})

def login_view(request):

    if request.method == 'POST':

        username = request.POST.get('username')
        password = request.POST.get('password')

        user = authenticate(
            request,
            username=username,
            password=password
        )

        if user is not None:
            login(request, user)
            return redirect('dashboard')

    return render(request, 'login.html')

@login_required
def dashboard(request):
    return render(request, 'dashboard.html')


@login_required
def logout_view(request):
    logout(request)
    return redirect('login')


@login_required
def salesforce_login(request):

    auth_url = SalesforceService.get_auth_url()
    return redirect(auth_url)

@login_required
def salesforce_callback(request):

    code = request.GET.get('code')

    token_data = SalesforceService.get_access_token(code)

    request.session['access_token'] = token_data['access_token']
    request.session['instance_url'] = token_data['instance_url']

    return redirect('validation_rules')

@login_required
def validation_rules(request):
    access_token = request.session.get('access_token')
    instance_url = request.session.get('instance_url')

    headers = {
        'Authorization': f'Bearer {access_token}',
        'Content-Type': 'application/json'
    }

    query = """
    SELECT Id, ValidationName, Active,
           EntityDefinition.QualifiedApiName
    FROM ValidationRule
    """

    url = f"{instance_url}/services/data/v59.0/tooling/query/"

    response = requests.get(
        url,
        headers=headers,
        params={'q': query}
    )

    data = response.json()

    rules = []

    for record in data.get('records', []):
        rules.append({
            'id': record['Id'],
            'object': record['EntityDefinition']['QualifiedApiName'],
            'name': record['ValidationName'],
            'active': record['Active']
        })

    return render(request, 'validation_rules.html', {
        'rules': rules
    })

@login_required
def toggle_rule(request, rule_id):

    access_token = request.session.get('access_token')
    instance_url = request.session.get('instance_url')

    active = request.GET.get('active') == 'true'

    headers = {
        'Authorization': f'Bearer {access_token}',
        'Content-Type': 'application/json'
    }

    get_url = (
        f"{instance_url}"
        f"/services/data/v59.0/tooling/sobjects/"
        f"ValidationRule/{rule_id}"
    )

    get_response = requests.get(get_url, headers=headers)

    rule_data = get_response.json()

    metadata = rule_data.get('Metadata', {})

    metadata['active'] = active

    patch_payload = {
        "Metadata": metadata
    }

    patch_response = requests.patch(
        get_url,
        headers=headers,
        json=patch_payload
    )

    if patch_response.status_code == 204:
        return redirect('validation_rules')

    return JsonResponse({
        'status_code': patch_response.status_code,
        'response': patch_response.text
    })