from django.urls import path
from django.urls import reverse
from . import views
urlpatterns=[
    path('', views.login_view, name='login'),

    path('register/', views.register_view, name='register'),

    path('dashboard/', views.dashboard, name='dashboard'),

    path('logout/', views.logout_view, name='logout'),

    path(
        'salesforce/login/',
        views.salesforce_login,
        name='salesforce_login'
    ),
     path(
        'salesforce/callback/',
        views.salesforce_callback,
        name='salesforce_callback'
    ),

    path(
        'validation-rules/',
        views.validation_rules,
        name='validation_rules'
    ),
    
    path(
    'toggle-rule/<str:rule_id>/',
    views.toggle_rule,
    name='toggle_rule'
    ),
]