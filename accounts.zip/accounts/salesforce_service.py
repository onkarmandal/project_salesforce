import requests
from django.conf import settings


class SalesforceService:

    @staticmethod
    def get_auth_url():

        return (
            f"{settings.SALESFORCE_AUTH_URL}"
            f"?response_type=code"
            f"&client_id={settings.SALESFORCE_CLIENT_ID}"
            f"&redirect_uri={settings.SALESFORCE_REDIRECT_URI}"
        )
    
    @staticmethod
    def get_access_token(code):

        payload = {
            'grant_type': 'authorization_code',
            'client_id': settings.SALESFORCE_CLIENT_ID,
            'client_secret': settings.SALESFORCE_CLIENT_SECRET,
            'redirect_uri': settings.SALESFORCE_REDIRECT_URI,
            'code': code
        }

        response = requests.post(
            settings.SALESFORCE_TOKEN_URL,
            data=payload
        )

        return response.json()
    
    @staticmethod
    def fetch_validation_rules(access_token, instance_url):

        query = """
        SELECT Id,
               ValidationName,
               Active,
               EntityDefinition.QualifiedApiName
        FROM ValidationRule
        """

        headers = {
            'Authorization': f'Bearer {access_token}'
        }

        url = (
            f"{instance_url}"
            f"/services/data/v58.0/tooling/query/"
        )

        response = requests.get(
            url,
            headers=headers,
            params={'q': query}
        )

        return response.json()
    
    @staticmethod
    def toggle_validation_rule(
        access_token,
        instance_url,
        rule_id,
        active
    ):

        headers = {
            'Authorization': f'Bearer {access_token}',
            'Content-Type': 'application/json'
        }

        url = (
            f"{instance_url}"
            f"/services/data/v58.0/tooling/sobjects/"
            f"ValidationRule/{rule_id}"
        )

        payload = {
            "Metadata": {
                "active": active
            }
        }

        response = requests.patch(
            url,
            headers=headers,
            json=payload
        )

        return response.status_code